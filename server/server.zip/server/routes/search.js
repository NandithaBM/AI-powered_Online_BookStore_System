const express = require('express');
const router = express.Router();
const Book = require('../models/Book');
const semanticSearch = require('../services/semanticSearch');
const recommendationEngine = require('../services/recommendationEngine');

// Initialize search index
let searchInitialized = false;

async function initializeSearch() {
  if (!searchInitialized) {
    try {
      const books = await Book.find({});
      await semanticSearch.initializeIndex(books);
      searchInitialized = true;
      console.log('Search index initialized with', books.length, 'books');
    } catch (error) {
      console.error('Search initialization error:', error);
    }
  }
}

// Semantic search endpoint
router.get('/semantic', async (req, res) => {
  try {
    await initializeSearch();
    
    const { query, limit = 10 } = req.query;
    
    if (!query) {
      return res.status(400).json({ error: 'Search query is required' });
    }

    const results = semanticSearch.search(query, parseInt(limit));
    
    // Track search for analytics
    if (req.user) {
      recommendationEngine.trackInteraction(
        req.user.id, 
        null, 
        'search', 
        { query, resultsCount: results.length }
      );
    }

    res.json({
      query,
      results,
      totalFound: results.length
    });
  } catch (error) {
    console.error('Semantic search error:', error);
    res.status(500).json({ error: 'Search failed' });
  }
});

// Get search suggestions
router.get('/suggestions', async (req, res) => {
  try {
    await initializeSearch();
    
    const { q } = req.query;
    
    if (!q || q.length < 2) {
      return res.json({ suggestions: [] });
    }

    const suggestions = semanticSearch.getSuggestions(q);
    res.json({ suggestions });
  } catch (error) {
    console.error('Search suggestions error:', error);
    res.status(500).json({ error: 'Failed to get suggestions' });
  }
});

// Advanced search with filters
router.post('/advanced', async (req, res) => {
  try {
    const {
      query,
      genre,
      author,
      priceRange,
      rating,
      sortBy = 'relevance',
      limit = 20
    } = req.body;

    let searchResults = [];

    if (query) {
      await initializeSearch();
      searchResults = semanticSearch.search(query, limit * 2);
    } else {
      // If no query, get all books
      const books = await Book.find({});
      searchResults = books.map(book => ({ ...book._doc, relevanceScore: 0 }));
    }

    // Apply filters
    let filteredResults = searchResults;

    if (genre) {
      filteredResults = filteredResults.filter(book => 
        book.genre && book.genre.toLowerCase().includes(genre.toLowerCase())
      );
    }

    if (author) {
      filteredResults = filteredResults.filter(book => 
        book.author && book.author.toLowerCase().includes(author.toLowerCase())
      );
    }

    if (priceRange) {
      const { min, max } = priceRange;
      filteredResults = filteredResults.filter(book => 
        book.price >= min && book.price <= max
      );
    }

    if (rating) {
      filteredResults = filteredResults.filter(book => 
        book.rating >= rating
      );
    }

    // Sort results
    switch (sortBy) {
      case 'price-low':
        filteredResults.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filteredResults.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filteredResults.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      case 'newest':
        filteredResults.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      case 'relevance':
      default:
        // Already sorted by relevance from semantic search
        break;
    }

    const results = filteredResults.slice(0, limit);

    res.json({
      results,
      totalFound: filteredResults.length,
      filters: { genre, author, priceRange, rating, sortBy }
    });
  } catch (error) {
    console.error('Advanced search error:', error);
    res.status(500).json({ error: 'Advanced search failed' });
  }
});

// Re-index search (admin only)
router.post('/reindex', async (req, res) => {
  try {
    const books = await Book.find({});
    await semanticSearch.initializeIndex(books);
    searchInitialized = true;
    
    res.json({ 
      message: 'Search index rebuilt successfully',
      booksIndexed: books.length 
    });
  } catch (error) {
    console.error('Reindex error:', error);
    res.status(500).json({ error: 'Failed to rebuild search index' });
  }
});

module.exports = router;