import express from 'express';
import User from '../models/User.js';
import Book from '../models/Book.js';
import { auth } from '../middleware/auth.js';

const router = express.Router();

// Update user profile
router.put('/profile', auth, async (req, res) => {
  try {
    const updates = req.body;
    const user = await User.findByIdAndUpdate(
      req.user.userId,
      { $set: updates },
      { new: true, runValidators: true }
    );

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      message: 'Profile updated successfully',
      user,
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get wishlist
router.get('/wishlist', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId)
      .populate('wishlist', 'title author coverImage price ratings genre');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json(user.wishlist);
  } catch (error) {
    console.error('Get wishlist error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Add to wishlist
router.post('/wishlist/:bookId', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    const book = await Book.findById(req.params.bookId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (!book) {
      return res.status(404).json({ message: 'Book not found' });
    }

    if (user.wishlist.includes(req.params.bookId)) {
      return res.status(400).json({ message: 'Book already in wishlist' });
    }

    user.wishlist.push(req.params.bookId);
    await user.save();

    res.json({
      message: 'Book added to wishlist',
      wishlist: user.wishlist,
    });
  } catch (error) {
    console.error('Add to wishlist error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Remove from wishlist
router.delete('/wishlist/:bookId', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.wishlist = user.wishlist.filter(
      bookId => bookId.toString() !== req.params.bookId
    );
    await user.save();

    res.json({
      message: 'Book removed from wishlist',
      wishlist: user.wishlist,
    });
  } catch (error) {
    console.error('Remove from wishlist error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get reading history
router.get('/reading-history', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId)
      .populate('readingHistory.book', 'title author coverImage genre');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json(user.readingHistory);
  } catch (error) {
    console.error('Get reading history error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Add to reading history
router.post('/reading-history', auth, async (req, res) => {
  try {
    const { bookId, rating } = req.body;
    const user = await User.findById(req.user.userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const existingEntry = user.readingHistory.find(
      entry => entry.book.toString() === bookId
    );

    if (existingEntry) {
      existingEntry.rating = rating;
      existingEntry.dateRead = new Date();
    } else {
      user.readingHistory.push({
        book: bookId,
        rating,
        dateRead: new Date(),
      });
    }

    await user.save();

    res.json({
      message: 'Reading history updated',
      readingHistory: user.readingHistory,
    });
  } catch (error) {
    console.error('Add to reading history error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;