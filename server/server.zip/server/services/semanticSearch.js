// Semantic Search Service using TF-IDF and cosine similarity
// In production, this would use SBERT embeddings
const natural = require('natural');
const TfIdf = natural.TfIdf;

class SemanticSearchService {
  constructor() {
    this.tfidf = new TfIdf();
    this.documents = [];
    this.bookIndex = new Map();
  }

  // Initialize the search index with books
  async initializeIndex(books) {
    this.documents = [];
    this.bookIndex.clear();
    
    books.forEach((book, index) => {
      const searchableText = this.createSearchableText(book);
      this.tfidf.addDocument(searchableText);
      this.documents.push(searchableText);
      this.bookIndex.set(index, book);
    });
  }

  // Create searchable text from book data
  createSearchableText(book) {
    const fields = [
      book.title || '',
      book.author || '',
      book.description || '',
      book.genre || '',
      book.tags ? book.tags.join(' ') : '',
      book.isbn || ''
    ];
    return fields.join(' ').toLowerCase();
  }

  // Perform semantic search
  search(query, limit = 10) {
    if (!query || this.documents.length === 0) {
      return [];
    }

    const queryVector = [];
    this.tfidf.tfidfs(query.toLowerCase(), (i, measure) => {
      queryVector[i] = measure;
    });

    const similarities = [];
    for (let i = 0; i < this.documents.length; i++) {
      const similarity = this.cosineSimilarity(queryVector, this.getDocumentVector(i));
      if (similarity > 0.01) { // Threshold for relevance
        similarities.push({
          book: this.bookIndex.get(i),
          similarity,
          index: i
        });
      }
    }

    return similarities
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, limit)
      .map(item => ({
        ...item.book._doc || item.book,
        relevanceScore: item.similarity
      }));
  }

  // Get document vector for similarity calculation
  getDocumentVector(docIndex) {
    const vector = [];
    this.tfidf.listTerms(docIndex).forEach(item => {
      vector[item.term] = item.tfidf;
    });
    return vector;
  }

  // Calculate cosine similarity between vectors
  cosineSimilarity(vecA, vecB) {
    const dotProduct = this.dotProduct(vecA, vecB);
    const normA = Math.sqrt(this.dotProduct(vecA, vecA));
    const normB = Math.sqrt(this.dotProduct(vecB, vecB));
    
    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (normA * normB);
  }

  // Calculate dot product of two vectors
  dotProduct(vecA, vecB) {
    let product = 0;
    const allKeys = new Set([...Object.keys(vecA), ...Object.keys(vecB)]);
    
    allKeys.forEach(key => {
      const a = vecA[key] || 0;
      const b = vecB[key] || 0;
      product += a * b;
    });
    
    return product;
  }

  // Get search suggestions based on partial query
  getSuggestions(partialQuery, limit = 5) {
    if (!partialQuery || partialQuery.length < 2) return [];

    const suggestions = new Set();
    const query = partialQuery.toLowerCase();

    // Find matching terms from documents
    this.documents.forEach(doc => {
      const words = doc.split(/\s+/);
      words.forEach(word => {
        if (word.includes(query) && word.length > query.length) {
          suggestions.add(word);
        }
      });
    });

    return Array.from(suggestions).slice(0, limit);
  }
}

module.exports = new SemanticSearchService();